import Questao01X from "./components/prova01/questao1";
import Questao02 from "./components/prova01/questao2";
import Questao03 from "./components/prova01/questao3";

function App() {
  return (
    <div className="App">
      <Questao01X />
      <hr />
      <Questao02 />
      <hr />
      <Questao03 />
    </div>
  );
}

export default App;


// atividades/src/components/prova01