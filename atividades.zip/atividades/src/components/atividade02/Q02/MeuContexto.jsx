import { createContext } from 'react';

const PokemonId = createContext(1);

export default PokemonId;