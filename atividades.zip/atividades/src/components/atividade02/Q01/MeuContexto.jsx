import { createContext } from 'react';

const MinhaCor = createContext();

export default MinhaCor;