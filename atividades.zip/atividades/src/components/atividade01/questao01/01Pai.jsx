import Filho from './01Filho';

const Pai = ({ Faltura, Fpeso }) => {
    return <Filho altura={Faltura} peso={Fpeso}/>
}

export default Pai;